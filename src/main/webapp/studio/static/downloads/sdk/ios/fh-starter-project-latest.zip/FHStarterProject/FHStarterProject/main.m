//
//  main.m
//  FHStarterProject
//
//  Created by Wei Li on 14/08/2012.
//  Copyright (c) 2012 FeedHenry. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
